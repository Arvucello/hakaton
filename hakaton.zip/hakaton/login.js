var form = document.getElementById("forma");
form.addEventListener("submit", function (e) {
    e.preventDefault();
    var baza = [
        { username: 'ucenik1', password: 'uce1', id: 1, ime: 'Mara', prezime:'Maric', odeljenje: 'I1', poeni: 50},
        {username: 'ucenik2', password: 'uce2', id: 1, ime: 'Pera', prezime:'Maric', odeljenje: 'I2', poeni: 50},
        {username: 'ucenik3', password: 'uce3', id: 1, ime: 'Mika', prezime:'Maric', odeljenje: 'I3', poeni: 50},
        {username: 'ucenik4', password: 'uce4', id: 1, ime: 'Fica', prezime:'Maric', odeljenje: 'I4', poeni: 50},
        {username: 'ucenik5', password: 'uce5', id: 1, ime: 'Ficko', prezime:'Cubaric', odeljenje: 'II1', poeni: 50},
        {username: 'ucenik6', password: 'uce6', id: 1, ime: 'Ficica', prezime:'Maric', odeljenje: 'II2', poeni: 50},
        {username: 'ucenik7', password: 'uce7', id: 1, ime: 'Ma', prezime:'Maric', odeljenje: 'III1', poeni: 50},
        {username: 'ucenik8', password: 'uce8', id: 1, ime: 'Mar', prezime:'Maric', odeljenje: 'III2', poeni: 50},
        {username: 'ucenik9', password: 'uce9', id: 1, ime: 'M', prezime:'Maric', odeljenje: 'III3', poeni: 50},
        {username: 'ucenik10', password: 'uce10', id: 1, ime: 'Nara', prezime:'Maric', odeljenje: 'IV1', poeni: 50},
        {username: 'ucenik11', password: 'uce11', id: 1, ime: 'Marko', prezime:'Maric', odeljenje: 'IV2', poeni: 50}
    ];
    var i = 0;




}, false)