<!DOCTYPE html>
<html lang="en">
<head>
    <link href="stil.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

   


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Predavanja</title>
</head>


<body>
    
        <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <a class="navbar-brand" href="index.html">Digitalna škola</a>
                  </div>
                  <ul class="nav navbar-nav">
                    
                   
                    
                    <li><a href="predavanja.html" class="prvi">Predavanja</a></li>
                    <li><a href="testovi.html">Testovi</a></li>
                    <li><a href="uspeh.php">Uspeh</a></li>
                    <li><a href="profil.php">Profil</a></li>
                    <li><a href = "index.php">Logout</a></li>
                  </ul>
                </div>
              </nav>

    <div class="div1">
                    <br> <img src = "olovka.jpg" style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 5 poena </p>     
                  
                      </div>
                      <div class="div1">
                    <br> <img src = "gumica.jpg"  style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 5 poena </p>     
                  
                      </div>
                      <div class="div1">
                    <br> <img src = "rezac.jpg" style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 7 poena </p>     
                  
                      </div>
                      <div class="div1">
                    <br> <img src = "bojice.jpg" style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 15 poena </p>     
                  
                      </div>
                      <div class="div1">
                    <br> <img src = "penkalo.jpg" style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 30 poena </p>     
                  
                      </div>
                      <div class="div1">
                    <br> <img src = "pernica.jpg" style = "width: 100%; height: 100%;"><br>
                        <p style="font-size: 200%; padding-top: 30px;"> 20 poena </p>     
                  
                      </div>



</body>
</html>